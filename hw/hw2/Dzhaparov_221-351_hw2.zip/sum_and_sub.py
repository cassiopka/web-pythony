def sum_and_sub(a, b):
    return a + b, a - b